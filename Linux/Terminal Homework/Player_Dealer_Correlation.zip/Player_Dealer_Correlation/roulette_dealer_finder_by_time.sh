#!/bin/bash
echo " "
echo " "

echo "###THIS SCRIPT WILL LOOKUP THE DEALER FIRST AND LAST NAME BY TYPING THE DATE AND TIME###"
echo " "
echo " " 

read -p "Type The Date in Four Digits MM/DD:  " date
echo " "

read -p "Type The Time in hh:mm:ss format:  " dealertime
echo " "

read -p " AM or PM?   " ampm
echo " "

echo "The Name of the Dealer Working at the specific date/time is: "
cat dealerschedule.txt | grep $date |grep $dealertime | grep -i $ampm | awk -F " " '{print $1, $2, $3, $5, $6}'

echo " "
echo " "
echo "###DEALER SCHEDULE BELOW FOR VERIFICATION###"
echo " "
cat dealerschedule.txt | awk -F " " '{print $1, $2, $3, $5, $6}'
